# table-authoring

Error: Tab from preceding prose must discover a table handle without hovering the table
    at evalmachine.<anonymous>:115:31
    at runNextTicks (node:internal/process/task_queues:65:5)
    at processImmediate (node:internal/timers:541:9)
    at file:///home/runner/work/ieumdoc/ieumdoc/apps/editor/test/browser/scenarios.spec.ts:148:20
    at /home/runner/work/ieumdoc/ieumdoc/node_modules/.pnpm/playwright@1.64.0-alpha-1789764292000/node_modules/playwright/lib/worker/workerProcessEntry.js:1654:9
    at /home/runner/work/ieumdoc/ieumdoc/node_modules/.pnpm/playwright@1.64.0-alpha-1789764292000/node_modules/playwright/lib/worker/workerProcessEntry.js:1134:11
    at TimeoutManager.withRunnable (/home/runner/work/ieumdoc/ieumdoc/node_modules/.pnpm/playwright@1.64.0-alpha-1789764292000/node_modules/playwright/lib/worker/workerProcessEntry.js:403:14)
    at TestInfoImpl._runWithTimeout (/home/runner/work/ieumdoc/ieumdoc/node_modules/.pnpm/playwright@1.64.0-alpha-1789764292000/node_modules/playwright/lib/worker/workerProcessEntry.js:1132:7)
    at /home/runner/work/ieumdoc/ieumdoc/node_modules/.pnpm/playwright@1.64.0-alpha-1789764292000/node_modules/playwright/lib/worker/workerProcessEntry.js:1652:7
    at WorkerMain._runTest (/home/runner/work/ieumdoc/ieumdoc/node_modules/.pnpm/playwright@1.64.0-alpha-1789764292000/node_modules/playwright/lib/worker/workerProcessEntry.js:1625:5)

## Page snapshot

```yaml
- navigation "Application":
  - text: IeumDoc
  - button "Open folder…"
  - button "Collapse sidebar" [expanded]
  - group "Sidebar tools":
    - button "Files" [expanded] [pressed]
    - button "Display"
  - region "table-authoring":
    - button "New file in folder"
    - button "New folder"
    - button "More actions"
    - paragraph:
      - button "Collapse folder table-authoring" [expanded]
      - text: table-authoring
    - tree "table-authoring":
      - treeitem "tables.md" [level=1]
  - button "Settings"
- banner:
  - status: Unsaved changes
  - button "Command center": table-authoring tables.md
  - group "View controls":
    - group "Document view":
      - button "Visual" [pressed]
      - button "Source"
    - button "Outline" [pressed]
  - group "File actions":
    - button "Save"
    - button "File actions"
- tablist "Documents":
  - tab "technical-document.md"
  - button "Close technical-document.md"
  - tab "tables.md, Unsaved changes" [selected]: tables.md
  - button "Close tables.md"
- main:
  - tabpanel "tables.md, Unsaved changes":
    - article:
      - button "Add a title"
      - heading "Tables" [level=2]
      - paragraph: Intro paragraph.
      - table:
        - rowgroup:
          - row "Name Value":
            - columnheader "Name"
            - columnheader "Value"
          - row "U AC":
            - cell "U"
            - cell "AC"
      - button "Insert block after heading block 1"
      - button "Move heading block 1"
      - button "Insert block after paragraph block 2"
      - button "Move paragraph block 2"
      - button "Insert block after table block 3"
      - button "Move table block 3"
- complementary "Outline":
  - heading "Outline" [level=2]
  - button "Hide outline"
  - region "Outline":
    - list:
      - listitem:
        - button "Tables"
```
